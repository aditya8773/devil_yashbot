# Power By @BikashHalder & @AdityaHalder 
# Join @BikashGadgetsTech For More Update
# Join @AdityaCheats For Hack
# Join Our Chats @Bgt_Chat & @Adityadiscus 


class AssistantErr(Exception):
    def __init__(self, errr: str):
        super().__init__(errr)
